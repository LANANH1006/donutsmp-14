package com.donutlike;

import net.fabricmc.fabric.api.event.player.PlayerBlockBreakEvents;
import net.fabricmc.fabric.api.event.player.UseBlockCallback;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.component.type.LoreComponent;
import net.minecraft.component.type.NbtComponent;
import net.minecraft.enchantment.Enchantments;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.inventory.SimpleInventory;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.registry.Registries;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.screen.GenericContainerScreenHandler;
import net.minecraft.screen.ScreenHandlerType;
import net.minecraft.screen.SimpleNamedScreenHandlerFactory;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.text.Text;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.BlockPos;

import java.util.*;

/**
 * Spawner kieu DonutSMP:
 *  - Chuot phai spawner dang dat bang spawner CUNG LOAI = gop them 1 (Shift = gop ca stack trong tay).
 *  - Dat spawner moi: Shift + dat = dat ca stack thanh 1 spawner x N.
 *  - Dao bang Silk Touch: lay 1 spawner ra khoi stack; Shift + dao = lay ca stack. Khong Silk Touch thi khong dao duoc.
 *  - Spawner khong sinh quai: tu sinh DO (loot) vao kho cua no. Chuot phai spawner (tay khong/khong Shift) = mo kho:
 *    moi o = 1 stack, co trang (mui ten trai/phai), nut Dropper = lay het do cua trang, chai exp = nhan exp, Ban tat ca.
 */
public class Spawners {

    public static class Data {
        public String mob = "pig";
        public int count = 1;
        public Map<String, Long> items = new HashMap<>();
        public long xp = 0; // exp tich luy (lay bang nut chai exp trong menu)
    }

    static final Random R = new Random();
    /** mob -> {id item, min, max} moi 10 giay moi spawner trong stack */
    static final Map<String, Object[][]> LOOT = new HashMap<>();
    static {
        LOOT.put("pig", new Object[][]{{"porkchop", 1, 3}});
        LOOT.put("cow", new Object[][]{{"beef", 1, 3}, {"leather", 0, 2}});
        LOOT.put("skeleton", new Object[][]{{"bone", 0, 2}, {"arrow", 0, 2}});
        LOOT.put("blaze", new Object[][]{{"blaze_rod", 0, 1}});
        LOOT.put("creeper", new Object[][]{{"gunpowder", 0, 2}});
        LOOT.put("zombie", new Object[][]{{"rotten_flesh", 0, 2}});
        LOOT.put("spider", new Object[][]{{"string", 0, 2}, {"spider_eye", 0, 1}});
        LOOT.put("iron_golem", new Object[][]{{"iron_ingot", 3, 5}});
    }

    /** exp moi lan sinh (moi spawner trong stack, moi 10 giay) */
    static final Map<String, Integer> XP = new HashMap<>();
    static {
        XP.put("pig", 2); XP.put("cow", 2); XP.put("skeleton", 5); XP.put("blaze", 10);
        XP.put("creeper", 5); XP.put("zombie", 5); XP.put("spider", 5); XP.put("iron_golem", 0);
    }
    static final long XP_CAP = 10_000_000L;

    /** Thu tu hien thi: theo thu tu trong LOOT (skeleton: bone truoc, arrow o cuoi), do la xep sau. */
    static List<String> orderedIds(Data d) {
        List<String> ids = new ArrayList<>(d.items.keySet());
        Object[][] loot = LOOT.get(d.mob);
        List<String> order = new ArrayList<>();
        if (loot != null) for (Object[] l : loot) order.add((String) l[0]);
        ids.sort((a, b) -> {
            int ia = order.indexOf(a), ib = order.indexOf(b);
            if (ia < 0) ia = 1000; if (ib < 0) ib = 1000;
            return ia != ib ? Integer.compare(ia, ib) : a.compareTo(b);
        });
        return ids;
    }

    static Map<String, Data> map() {
        if (DonutLike.save.spawners == null) DonutLike.save.spawners = new HashMap<>();
        return DonutLike.save.spawners;
    }

    static String key(ServerWorld w, BlockPos p) {
        return w.getRegistryKey().getValue() + "|" + p.getX() + "," + p.getY() + "," + p.getZ();
    }

    static String mobOf(ItemStack s) {
        NbtComponent c = s.get(DataComponentTypes.BLOCK_ENTITY_DATA);
        if (c == null) return null;
        NbtCompound n = c.copyNbt();
        String id = n.getCompound("SpawnData").getCompound("entity").getString("id");
        if (id == null || id.isEmpty()) return null;
        return id.replace("minecraft:", "");
    }

    static boolean hasSilk(ItemStack s) {
        if (s.isEmpty()) return false;
        for (var e : s.getEnchantments().getEnchantments()) if (e.matchesKey(Enchantments.SILK_TOUCH)) return true;
        return false;
    }

    static Item item(String id) { return Registries.ITEM.get(Identifier.of("minecraft", id)); }

    static void init() {
        UseBlockCallback.EVENT.register((player, world, hand, hit) -> {
            if (world.isClient || hand != Hand.MAIN_HAND || !(player instanceof ServerPlayerEntity sp) || !(world instanceof ServerWorld sw))
                return ActionResult.PASS;
            BlockPos pos = hit.getBlockPos();
            ItemStack held = player.getStackInHand(hand);
            BlockState st = world.getBlockState(pos);
            String mobHeld = held.isOf(Items.SPAWNER) ? mobOf(held) : null;

            if (st.isOf(Blocks.SPAWNER)) {
                Data d = map().get(key(sw, pos));
                if (d == null) return ActionResult.PASS;
                if (mobHeld != null && mobHeld.equals(d.mob)) {                 // gop stack
                    int n = player.isSneaking() ? held.getCount() : 1;
                    if (!sp.isCreative()) held.decrement(n);
                    d.count += n;
                    ShopHandler.ting(sp);
                    sp.sendMessage(Text.literal("§aĐã gộp +" + n + " §7→ §d" + name(d.mob) + " Spawner x" + d.count), true);
                    return ActionResult.SUCCESS;
                }
                if (!player.isSneaking()) { openGui(sp, key(sw, pos)); return ActionResult.SUCCESS; }
                return ActionResult.PASS;
            }

            if (mobHeld != null) {                                              // dat spawner moi
                BlockPos placed = st.isReplaceable() ? pos : pos.offset(hit.getSide());
                int n = player.isSneaking() ? held.getCount() : 1;
                String mob = mobHeld;
                boolean creative = sp.isCreative();
                Duels.later(1, () -> {
                    if (!sw.getBlockState(placed).isOf(Blocks.SPAWNER)) return;
                    String k = key(sw, placed);
                    if (map().containsKey(k)) return;
                    Data nd = new Data();
                    nd.mob = mob;
                    nd.count = 1;
                    if (n > 1) {
                        int take = creative ? n - 1 : Math.min(n - 1, held.getCount());
                        if (!creative) held.decrement(take);
                        nd.count += take;
                    }
                    map().put(k, nd);
                });
            }
            return ActionResult.PASS;
        });

        PlayerBlockBreakEvents.BEFORE.register((world, player, pos, state, be) -> {
            if (world.isClient || !state.isOf(Blocks.SPAWNER) || !(player instanceof ServerPlayerEntity sp) || !(world instanceof ServerWorld sw)) return true;
            Data d = map().get(key(sw, pos));
            if (d == null) return true;
            if (!hasSilk(sp.getMainHandStack())) {
                sp.sendMessage(Text.literal("§cCần cúp có §dSilk Touch §cđể đào spawner."), true);
                return false;
            }
            int give = Math.min(d.count, sp.isSneaking() ? d.count : 1);
            d.count -= give;
            while (give > 0) {
                int n = Math.min(64, give);
                sp.getInventory().offerOrDrop(ShardShop.spawner(d.mob).copyWithCount(n));
                give -= n;
            }
            if (d.count <= 0) {
                for (Map.Entry<String, Long> e : d.items.entrySet()) giveItems(sp, e.getKey(), e.getValue());
                if (d.xp > 0) sp.addExperience((int) Math.min(Integer.MAX_VALUE, d.xp));
                map().remove(key(sw, pos));
                sw.breakBlock(pos, false);
                sp.sendMessage(Text.literal("§aĐã lấy hết spawner (đồ bên trong đã trả về túi)."), true);
            } else {
                sp.sendMessage(Text.literal("§aCòn lại §d" + name(d.mob) + " Spawner x" + d.count), true);
            }
            return false;
        });
    }

    static String name(String mob) { return mob.isEmpty() ? mob : mob.substring(0, 1).toUpperCase() + mob.substring(1); }

    static void giveItems(ServerPlayerEntity sp, String id, long amount) {
        Item it = item(id);
        while (amount > 0) {
            int n = (int) Math.min(it.getMaxCount(), amount);
            sp.getInventory().offerOrDrop(new ItemStack(it, n));
            amount -= n;
        }
    }

    /** moi 10 giay: moi spawner sinh do vao kho */
    static void tick(MinecraftServer s) {
        if (DonutLike.tick % 200 != 0 || map().isEmpty()) return;
        Iterator<Map.Entry<String, Data>> it = map().entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry<String, Data> en = it.next();
            String[] a = en.getKey().split("\\|");
            String[] c = a[1].split(",");
            BlockPos pos = new BlockPos(Integer.parseInt(c[0]), Integer.parseInt(c[1]), Integer.parseInt(c[2]));
            ServerWorld w = s.getWorld(RegistryKey.of(RegistryKeys.WORLD, Identifier.of(a[0])));
            if (w == null) continue;
            if (!w.getChunkManager().isChunkLoaded(pos.getX() >> 4, pos.getZ() >> 4)) continue;
            if (!w.getBlockState(pos).isOf(Blocks.SPAWNER)) { it.remove(); continue; }
            Data d = en.getValue();
            Object[][] loot = LOOT.getOrDefault(d.mob, new Object[][]{{"bone", 1, 2}});
            for (Object[] l : loot) {
                int min = (Integer) l[1], max = (Integer) l[2];
                long add = 0;
                for (int i = 0; i < Math.min(d.count, 64); i++) add += min + R.nextInt(max - min + 1);
                if (d.count > 64) add = add * d.count / 64;
                if (add <= 0) continue;
                String id = (String) l[0];
                long cap = 100_000L * d.count;
                d.items.merge(id, add, Long::sum);
                if (d.items.get(id) > cap) d.items.put(id, cap);
            }
            int xpEach = XP.getOrDefault(d.mob, 1);
            if (xpEach > 0) d.xp = Math.min(XP_CAP, d.xp + (long) xpEach * d.count);
        }
    }

    // ===== GUI kho spawner =====
    static void openGui(ServerPlayerEntity p, String key) {
        p.openHandledScreen(new SimpleNamedScreenHandlerFactory(
            (id, inv, pl) -> new Gui(id, inv, new SimpleInventory(54), key), Text.literal("Spawner")));
    }

    /** 1 o trong menu = 1 stack do (toi da 64 hoac max count cua item) */
    record Cell(String id, long amount) {}

    static class Gui extends GenericContainerScreenHandler {
        static final int PER_PAGE = 45;
        static final int PREV = 45, MINUS = 46, QTY = 47, PLUS = 48, DROPPER = 49, XPB = 50, SELLALL = 51, INFO = 52, NEXT = 53;
        final SimpleInventory inv; final String key;
        int qty = 64;   // so luong moi lan lay/ban 1 o (chinh bang nut + -)
        int page = 0;
        List<Cell> entries = new ArrayList<>();
        int pages = 1;

        Gui(int id, PlayerInventory pinv, SimpleInventory inv, String key) {
            super(ScreenHandlerType.GENERIC_9X6, id, pinv, inv, 6);
            this.inv = inv; this.key = key;
            refresh();
        }

        /** chia do trong kho thanh cac stack, moi stack 1 o */
        void build(Data d) {
            entries.clear();
            for (String id : orderedIds(d)) {
                long n = d.items.get(id);
                int max = Math.max(1, item(id).getMaxCount());
                while (n > 0) {
                    long take = Math.min(max, n);
                    entries.add(new Cell(id, take));
                    n -= take;
                }
            }
            pages = Math.max(1, (entries.size() + PER_PAGE - 1) / PER_PAGE);
            page = Math.max(0, Math.min(page, pages - 1));
        }

        void refresh() {
            for (int i = 0; i < 54; i++) inv.setStack(i, ItemStack.EMPTY);
            Data d = map().get(key);
            if (d == null) return;
            build(d);
            double total = 0;
            for (Map.Entry<String, Long> e : d.items.entrySet()) total += Prices.unit(item(e.getKey())) * e.getValue() * Prices.SELL_RATE;
            for (int i = 0; i < PER_PAGE; i++) {
                int idx = page * PER_PAGE + i;
                if (idx >= entries.size()) break;
                Cell sl = entries.get(idx);
                double v = Prices.unit(item(sl.id())) * sl.amount() * Prices.SELL_RATE;
                ItemStack s = new ItemStack(item(sl.id()), (int) sl.amount());
                s.set(DataComponentTypes.LORE, new LoreComponent(List.of(
                    Text.literal("§eTrong ô: §f" + sl.amount() + " §7| Tổng kho: §f" + Prices.money(d.items.getOrDefault(sl.id(), 0L))),
                    Text.literal("§eGiá trị ô: §a$" + Prices.money(v)),
                    Text.literal("§aClick trái: lấy §f" + Math.min(qty, sl.amount()) + " §7| §aClick phải: bán §f" + Math.min(qty, sl.amount())))));
                inv.setStack(i, s);
            }
            for (int i = 45; i < 54; i++) inv.setStack(i, ShopHandler.icon(Items.GRAY_STAINED_GLASS_PANE, " "));
            if (page > 0) inv.setStack(PREV, ShopHandler.icon(Items.ARROW, "§e← Trang trước", "§7Trang " + page + "/" + pages));
            inv.setStack(MINUS, ShopHandler.icon(Items.RED_WOOL, "§c§l- Giảm", "§7Chuột trái: -1", "§7Chuột phải: -10", "§7Shift: -64"));
            ItemStack q = ShopHandler.icon(Items.PAPER, "§eSố lượng mỗi lần: §f" + qty, "§7Dùng + - để chỉnh");
            q.setCount(Math.max(1, Math.min(64, qty)));
            inv.setStack(QTY, q);
            inv.setStack(PLUS, ShopHandler.icon(Items.LIME_WOOL, "§a§l+ Tăng", "§7Chuột trái: +1", "§7Chuột phải: +10", "§7Shift: +64"));
            inv.setStack(DROPPER, ShopHandler.icon(Items.DROPPER, "§6§lDrop vật phẩm trang này", "§7Lấy toàn bộ đồ đang hiện ở trang " + (page + 1) + "/" + pages));
            inv.setStack(XPB, ShopHandler.icon(Items.EXPERIENCE_BOTTLE, "§a§lEXP: §f" + Prices.money(d.xp), "§7Click để nhận toàn bộ exp"));
            inv.setStack(SELLALL, ShopHandler.icon(Items.EMERALD, "§a§lBán tất cả", "§7Tổng giá trị: §a$" + Prices.money(total)));
            inv.setStack(INFO, ShopHandler.icon(Items.SPAWNER, "§d" + name(d.mob) + " Spawner x" + d.count, "§7Sinh đồ + exp vào kho mỗi 10 giây", "§7Trang " + (page + 1) + "/" + pages));
            if (page < pages - 1) inv.setStack(NEXT, ShopHandler.icon(Items.ARROW, "§eTrang sau →", "§7Trang " + (page + 2) + "/" + pages));
        }

        @Override
        public void onSlotClick(int slot, int button, SlotActionType type, PlayerEntity player) {
            if (player instanceof ServerPlayerEntity sp && type == SlotActionType.PICKUP && slot >= 0 && slot < 54) {
                Data d = map().get(key);
                if (d == null) { ShopHandler.later(sp, sp::closeHandledScreen); syncState(); return; }
                if (slot == PREV) { if (page > 0) page--; }
                else if (slot == NEXT) { if (page < pages - 1) page++; }
                else if (slot == MINUS || slot == PLUS) {
                    int step = button == 1 ? 10 : 1;
                    if (player.isSneaking()) step = 64;
                    qty = Math.max(1, Math.min(10_000, qty + (slot == PLUS ? step : -step)));
                } else if (slot == DROPPER) {
                    dropPage(sp, d);
                } else if (slot == XPB) {
                    if (d.xp <= 0) DonutLike.msg(sp, "§cChưa có exp trong spawner.");
                    else {
                        sp.addExperience((int) Math.min(Integer.MAX_VALUE, d.xp));
                        DonutLike.msg(sp, "§aĐã nhận §e" + Prices.money(d.xp) + " §aexp.");
                        d.xp = 0;
                        ShopHandler.ting(sp);
                    }
                } else if (slot == SELLALL) {
                    double total = 0;
                    for (Map.Entry<String, Long> e : d.items.entrySet()) total += Prices.unit(item(e.getKey())) * e.getValue() * Prices.SELL_RATE;
                    d.items.clear();
                    if (total > 0) { DonutLike.add(sp.getUuid(), total); ShopHandler.ting(sp); DonutLike.msg(sp, "§aĐã bán đồ trong spawner: §e+$" + Prices.money(total)); }
                } else if (slot < PER_PAGE) {
                    int idx = page * PER_PAGE + slot;
                    if (idx < entries.size()) clickSlot(sp, d, entries.get(idx), button);
                }
                refresh();
            }
            syncState();
        }

        void clickSlot(ServerPlayerEntity sp, Data d, Cell sl, int button) {
            String id = sl.id();
            Long have = d.items.get(id);
            if (have == null || have <= 0) return;
            long n = Math.min(Math.min(qty, sl.amount()), have);
            if (button == 1) {                                        // ban
                double v = Prices.unit(item(id)) * n * Prices.SELL_RATE;
                remove(d, id, n);
                DonutLike.add(sp.getUuid(), v);
                ShopHandler.ting(sp);
                DonutLike.msg(sp, "§aĐã bán: §e+$" + Prices.money(v));
            } else {                                                  // lay
                Item it = item(id);
                if (!Admin.on("shop_dropfull")) n = Math.min(n, ShopHandler.space(sp, it));
                if (n <= 0) { DonutLike.msg(sp, "§cTúi đồ đầy! Hãy dọn chỗ trống."); return; }
                giveItems(sp, id, n);
                remove(d, id, n);
            }
        }

        /** Dropper: lay (rot) toan bo do dang hien o trang hien tai */
        void dropPage(ServerPlayerEntity sp, Data d) {
            int from = page * PER_PAGE, to = Math.min(entries.size(), from + PER_PAGE);
            long got = 0;
            boolean full = false;
            for (int i = from; i < to; i++) {
                Cell sl = entries.get(i);
                Long have = d.items.get(sl.id());
                if (have == null || have <= 0) continue;
                long n = Math.min(sl.amount(), have);
                Item it = item(sl.id());
                if (!Admin.on("shop_dropfull")) {
                    long room = ShopHandler.space(sp, it);
                    if (room < n) full = true;
                    n = Math.min(n, room);
                }
                if (n <= 0) continue;
                giveItems(sp, sl.id(), n);
                remove(d, sl.id(), n);
                got += n;
            }
            if (got > 0) { ShopHandler.ting(sp); DonutLike.msg(sp, "§aĐã drop §f" + Prices.money(got) + " §avật phẩm của trang này." + (full ? " §c(túi đầy, còn sót lại)" : "")); }
            else DonutLike.msg(sp, full ? "§cTúi đồ đầy! Hãy dọn chỗ trống." : "§cTrang này không có đồ.");
        }

        void remove(Data d, String id, long n) {
            long left = d.items.getOrDefault(id, 0L) - n;
            if (left <= 0) d.items.remove(id); else d.items.put(id, left);
        }

        @Override public ItemStack quickMove(PlayerEntity player, int slot) { return ItemStack.EMPTY; }
    }
}
