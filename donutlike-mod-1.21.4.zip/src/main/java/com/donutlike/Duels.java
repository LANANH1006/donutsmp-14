package com.donutlike;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.BoolArgumentType;
import com.mojang.brigadier.arguments.DoubleArgumentType;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.minecraft.block.Block;
import net.minecraft.block.Blocks;
import net.minecraft.command.CommandSource;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.SpawnReason;
import net.minecraft.entity.attribute.EntityAttribute;
import net.minecraft.entity.attribute.EntityAttributeInstance;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.mob.MobEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.command.ServerCommandSource;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.world.World;

import java.util.*;

import static net.minecraft.server.command.CommandManager.argument;
import static net.minecraft.server.command.CommandManager.literal;

public class Duels {

    // ===== Dau truong (tren cao, trong the gioi chinh) =====
    static final int AX = 8000, AY = 200, AZ = 8000;

    static class Spec {
        String name; double health, damage, speed, reward; int tier, totems; boolean crystals;
        Spec(String n, double h, double d, int t, double sp, int tot, boolean c, double r) {
            name = n; health = h; damage = d; tier = t; speed = sp; totems = tot; crystals = c; reward = r;
        }
    }

    static class Duel {
        UUID player, bot; Spec spec; double bet; int totems; boolean ending;
        MobEntity botRef; long start;
        ItemStack[] saved; String backDim; double bx, by, bz; float byaw, bpitch;
    }

    static class Task { long at; Runnable r; }

    static final Map<String, Spec> SPECS = new LinkedHashMap<>();
    static final Map<UUID, Duel> DUELS = new HashMap<>();
    static final List<Task> TASKS = new ArrayList<>();

    // tier: 0 khong, 1 da, 2 sat, 3 kim cuong, 4 netherite
    static final Item[][] ARMOR = {
        {},
        {Items.LEATHER_HELMET, Items.LEATHER_CHESTPLATE, Items.LEATHER_LEGGINGS, Items.LEATHER_BOOTS},
        {Items.IRON_HELMET, Items.IRON_CHESTPLATE, Items.IRON_LEGGINGS, Items.IRON_BOOTS},
        {Items.DIAMOND_HELMET, Items.DIAMOND_CHESTPLATE, Items.DIAMOND_LEGGINGS, Items.DIAMOND_BOOTS},
        {Items.NETHERITE_HELMET, Items.NETHERITE_CHESTPLATE, Items.NETHERITE_LEGGINGS, Items.NETHERITE_BOOTS}
    };
    static final Item[] SWORD = {null, Items.WOODEN_SWORD, Items.IRON_SWORD, Items.DIAMOND_SWORD, Items.NETHERITE_SWORD};
    static final double[] BONUS = {0, 3, 5, 6, 7};
    static final EquipmentSlot[] SLOTS = {EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET};

    static {
        //                      ten      mau  sat thuong tier toc do  totem crystal thuong
        SPECS.put("noob",   new Spec("Noob",   20, 3.5, 1, 0.18, 0, false, 50));
        SPECS.put("normal", new Spec("Normal", 20, 6.0, 2, 0.23, 0, false, 150));
        SPECS.put("pro",    new Spec("Pro",    20, 7.0, 4, 0.27, 1, false, 400));
        SPECS.put("cpvp",   new Spec("CPVP",   20, 8.0, 4, 0.28, 3, true, 1000));
    }

    public static boolean inDuel(ServerPlayerEntity p) { return DUELS.containsKey(p.getUuid()); }

    static void later(long ticks, Runnable r) {
        Task t = new Task(); t.at = DonutLike.tick + ticks; t.r = r; TASKS.add(t);
    }

    // ===== Dang ky =====
    static void init() {
        ServerLivingEntityEvents.ALLOW_DEATH.register((entity, src, amt) -> {
            if (entity instanceof ServerPlayerEntity p) {
                Duel d = DUELS.get(p.getUuid());
                if (d == null) return true;
                p.setHealth(p.getMaxHealth());
                p.extinguish();
                if (!d.ending) {
                    d.ending = true;
                    later(1, () -> { if (DonutLike.SERVER != null) endDuel(DonutLike.SERVER, d, false); });
                }
                return false;
            }
            for (Duel d : DUELS.values()) {
                if (!d.ending && d.totems > 0 && d.bot.equals(entity.getUuid())) {
                    d.totems--;
                    entity.setHealth(entity.getMaxHealth() * 0.5f);
                    if (entity.getWorld() instanceof ServerWorld sw) {
                        sw.spawnParticles(ParticleTypes.TOTEM_OF_UNDYING, entity.getX(), entity.getY() + 1, entity.getZ(), 30, 0.3, 0.5, 0.3, 0.2);
                        sw.playSound(null, entity.getX(), entity.getY(), entity.getZ(), SoundEvents.ITEM_TOTEM_USE, SoundCategory.HOSTILE, 1f, 1f);
                    }
                    ServerPlayerEntity pl = DonutLike.SERVER == null ? null : DonutLike.SERVER.getPlayerManager().getPlayer(d.player);
                    if (pl != null) DonutLike.msg(pl, "§e[Bot] đã pop totem! Còn " + d.totems + " totem.");
                    return false;
                }
            }
            return true;
        });

        ServerLivingEntityEvents.AFTER_DEATH.register((entity, src) -> {
            if (entity instanceof ServerPlayerEntity p) {
                ExtraCommands.inc(DonutLike.save.deaths, p.getUuid(), 1);
                if (src.getAttacker() instanceof ServerPlayerEntity k && k != p)
                    ExtraCommands.inc(DonutLike.save.kills, k.getUuid(), 1);
            }
        });

        ServerPlayConnectionEvents.DISCONNECT.register((handler, server) -> {
            Duel d = DUELS.get(handler.getPlayer().getUuid());
            if (d != null) { d.ending = true; endDuel(server, d, false); }
        });
    }

    static void endAll(MinecraftServer s) {
        for (Duel d : new ArrayList<>(DUELS.values())) { d.ending = true; endDuel(s, d, false); }
    }

    // ===== Lenh =====
    static void register(CommandDispatcher<ServerCommandSource> disp) {
        disp.register(literal("duel").requires(s -> Admin.on("duels"))
            .executes(c -> {
                ServerPlayerEntity p = c.getSource().getPlayerOrThrow();
                Spec sp = autoSpec(p);
                DonutLike.msg(p, "§7Bot được chọn tự động: §c" + sp.name);
                startDuel(p, sp, 0);
                return 1;
            })
            .then(literal("bot")
                .then(argument("level", StringArgumentType.word())
                    .suggests((c, b) -> CommandSource.suggestMatching(List.of("noob", "normal", "pro", "cpvp"), b))
                    .executes(c -> cmdBot(c, 0))
                    .then(argument("bet", DoubleArgumentType.doubleArg(1)).executes(c -> cmdBot(c, DoubleArgumentType.getDouble(c, "bet"))))))
            .then(literal("custom")
                .then(argument("health", IntegerArgumentType.integer(1, 200))
                .then(argument("damage", DoubleArgumentType.doubleArg(0.5, 30))
                .then(argument("speed", DoubleArgumentType.doubleArg(0.1, 0.6))
                .then(argument("armor", IntegerArgumentType.integer(0, 4))
                .then(argument("totems", IntegerArgumentType.integer(0, 10))
                .then(argument("crystals", BoolArgumentType.bool()).executes(c -> {
                    ServerPlayerEntity p = c.getSource().getPlayerOrThrow();
                    Spec sp = new Spec("Custom",
                        IntegerArgumentType.getInteger(c, "health"),
                        DoubleArgumentType.getDouble(c, "damage"),
                        IntegerArgumentType.getInteger(c, "armor"),
                        DoubleArgumentType.getDouble(c, "speed"),
                        IntegerArgumentType.getInteger(c, "totems"),
                        BoolArgumentType.getBool(c, "crystals"), 0);
                    startDuel(p, sp, 0);
                    return 1;
                }))))))))
            .then(literal("leave").executes(c -> {
                ServerPlayerEntity p = c.getSource().getPlayerOrThrow();
                Duel d = DUELS.get(p.getUuid());
                if (d == null) { DonutLike.msg(p, "§cBạn không ở trong duel."); return 0; }
                d.ending = true;
                endDuel(c.getSource().getServer(), d, false);
                return 1;
            })));
    }

    static int cmdBot(CommandContext<ServerCommandSource> c, double bet) throws CommandSyntaxException {
        ServerPlayerEntity p = c.getSource().getPlayerOrThrow();
        Spec sp = SPECS.get(StringArgumentType.getString(c, "level").toLowerCase());
        if (sp == null) { DonutLike.msg(p, "§cLevel hợp lệ: noob, normal, pro, cpvp"); return 0; }
        startDuel(p, sp, bet);
        return 1;
    }

    // ===== Bat dau duel =====
    static void startDuel(ServerPlayerEntity p, Spec sp, double bet) {
        if (!DUELS.isEmpty()) { DonutLike.msg(p, "§cĐấu trường đang có người duel, thử lại sau."); return; }
        if (DonutLike.bal(p.getUuid()) < bet) { DonutLike.msg(p, "§cKhông đủ tiền cược."); return; }
        MinecraftServer s = p.getServer();
        ServerWorld ow = s.getOverworld();

        // FIX: nap + giu chunk dau truong truoc khi xay/spawn bot (truoc day bot spawn o chunk chua nap -> duel bi huy ngay -> bi day ve cho cu)
        forceArena(ow, true);
        buildArena(ow);

        MobEntity bot = EntityType.HUSK.create(ow, SpawnReason.COMMAND);
        if (bot == null) { DonutLike.msg(p, "§cKhông tạo được bot."); return; }
        bot.refreshPositionAndAngles(AX + 8.5, AY, AZ + 0.5, 90f, 0f);
        attr(bot, EntityAttributes.MAX_HEALTH, sp.health);
        bot.setHealth((float) sp.health);
        attr(bot, EntityAttributes.ATTACK_DAMAGE, Math.max(0.1, sp.damage - BONUS[sp.tier]));
        attr(bot, EntityAttributes.MOVEMENT_SPEED, sp.speed);
        attr(bot, EntityAttributes.FOLLOW_RANGE, 40);
        if (sp.tier > 0) {
            for (int i = 0; i < 4; i++) bot.equipStack(SLOTS[i], new ItemStack(ARMOR[sp.tier][i]));
            if (sp.damage >= BONUS[sp.tier]) bot.equipStack(EquipmentSlot.MAINHAND, new ItemStack(SWORD[sp.tier]));
        }
        bot.setCustomName(Text.literal("§c[Bot " + sp.name + "]"));
        bot.setCustomNameVisible(true);
        bot.setPersistent();
        bot.setAiDisabled(true); // dung yen trong luc dem nguoc
        ow.spawnEntity(bot);

        Duel d = new Duel();
        d.botRef = bot; d.start = DonutLike.tick;
        d.player = p.getUuid(); d.bot = bot.getUuid(); d.spec = sp; d.bet = bet; d.totems = sp.totems;
        d.backDim = p.getWorld().getRegistryKey().getValue().toString();
        d.bx = p.getX(); d.by = p.getY(); d.bz = p.getZ(); d.byaw = p.getYaw(); d.bpitch = p.getPitch();
        d.saved = new ItemStack[p.getInventory().size()];
        for (int i = 0; i < d.saved.length; i++) d.saved[i] = p.getInventory().getStack(i).copy();
        DUELS.put(p.getUuid(), d);

        DonutLike.add(p.getUuid(), -bet);
        p.getInventory().clear();
        giveKit(p, sp);
        p.setHealth(p.getMaxHealth());
        p.getHungerManager().setFoodLevel(20);
        p.clearStatusEffects();
        p.extinguish();
        p.teleport(ow, AX - 7.5, AY, AZ + 0.5, Set.of(), -90f, 0f, true);

        DonutLike.msg(p, "§6Duel với Bot " + sp.name + (bet > 0 ? " §7(cược $" + DonutLike.fmt(bet) + ")" : "") + " §6bắt đầu sau 3 giây!");
        for (int i = 1; i <= 3; i++) {
            final int n = 3 - i;
            later(20L * i, () -> { if (n > 0) DonutLike.msg(p, "§e" + n + "..."); });
        }
        later(60, () -> {
            if (d.botRef != null) d.botRef.setAiDisabled(false);
            ServerPlayerEntity pl = s.getPlayerManager().getPlayer(d.player);
            if (pl != null) DonutLike.msg(pl, "§c§lFIGHT!");
        });
    }

    static void giveKit(ServerPlayerEntity p, Spec sp) {
        int pt = Math.max(2, sp.tier);
        for (int i = 0; i < 4; i++) p.equipStack(SLOTS[i], new ItemStack(ARMOR[pt][i]));
        p.getInventory().setStack(0, new ItemStack(SWORD[pt]));
        p.getInventory().setStack(1, new ItemStack(Items.GOLDEN_APPLE, 16));
        p.getInventory().setStack(2, new ItemStack(Items.COOKED_BEEF, 32));
        if (sp.crystals) {
            p.getInventory().setStack(3, new ItemStack(Items.END_CRYSTAL, 16));
            p.getInventory().setStack(4, new ItemStack(Items.OBSIDIAN, 16));
        }
        if (pt == 4) p.equipStack(EquipmentSlot.OFFHAND, new ItemStack(Items.TOTEM_OF_UNDYING));
    }

    // ===== Ket thuc duel =====
    static void endDuel(MinecraftServer s, Duel d, boolean win) {
        if (DUELS.remove(d.player) == null) return;
        ServerWorld ow = s.getOverworld();
        Entity bot = d.botRef != null ? d.botRef : ow.getEntity(d.bot);
        if (bot != null) bot.discard();

        ServerPlayerEntity p = s.getPlayerManager().getPlayer(d.player);
        if (p != null) {
            p.getInventory().clear();
            for (int i = 0; i < d.saved.length; i++) p.getInventory().setStack(i, d.saved[i]);
            p.setHealth(p.getMaxHealth());
            p.getHungerManager().setFoodLevel(20);
            p.clearStatusEffects();
            p.extinguish();
            ServerWorld bw = s.getWorld(RegistryKey.of(RegistryKeys.WORLD, Identifier.of(d.backDim)));
            if (bw == null) bw = ow;
            p.teleport(bw, d.bx, d.by, d.bz, Set.of(), d.byaw, d.bpitch, true);
        }

        String id = d.player.toString();
        if (win) {
            double prize = d.bet * 2 + d.spec.reward;
            DonutLike.add(d.player, prize);
            ExtraCommands.inc(DonutLike.save.duelWins, d.player, 1);
            if (d.spec.reward > 0) ExtraCommands.inc(DonutLike.save.shards, d.player, Math.max(1, (int) (d.spec.reward / 100)));
            if (p != null) DonutLike.msg(p, "§a§lBẠN THẮNG! §eNhận $" + DonutLike.fmt(prize));
        } else {
            ExtraCommands.inc(DonutLike.save.duelLosses, d.player, 1);
            if (p != null) DonutLike.msg(p, "§c§lBẠN THUA!" + (d.bet > 0 ? " §7Mất $" + DonutLike.fmt(d.bet) : ""));
        }

        // don rac trong dau truong sau 2 giay
        later(40, () -> {
            Box box = new Box(AX - 14, AY - 2, AZ - 14, AX + 14, AY + 12, AZ + 14);
            for (Entity e : ow.getEntitiesByClass(Entity.class, box, e -> !(e instanceof PlayerEntity))) e.discard();
            if (DUELS.isEmpty()) forceArena(ow, false);
        });
    }

    // ===== Moi tick =====
    static void tick(MinecraftServer s) {
        if (!TASKS.isEmpty()) {
            for (Task t : new ArrayList<>(TASKS)) {
                if (DonutLike.tick >= t.at) { TASKS.remove(t); t.r.run(); }
            }
        }
        if (DUELS.isEmpty()) return;
        ServerWorld ow = s.getOverworld();
        for (Duel d : new ArrayList<>(DUELS.values())) {
            if (d.ending) continue;
            ServerPlayerEntity p = s.getPlayerManager().getPlayer(d.player);
            if (p == null) { d.ending = true; endDuel(s, d, false); continue; }
            MobEntity bot = d.botRef;
            if (bot == null) { d.ending = true; endDuel(s, d, false); continue; }
            // co 3 giay "an han" dau tran de chunk/entity kip nap, tranh ket thuc nham
            if (DonutLike.tick - d.start > 60 && (bot.isRemoved() || !bot.isAlive())) { d.ending = true; endDuel(s, d, true); continue; }
            if (DonutLike.tick % 20 == 0) bot.setTarget(p);
            if (d.spec.crystals && !bot.isAiDisabled() && DonutLike.tick % 50 == 0 && DonutLike.R.nextInt(100) < 70)
                crystalHit(ow, bot, p);
        }
    }

    // Mo phong crystal: no ngay canh nguoi choi (khong pha block)
    static void crystalHit(ServerWorld w, MobEntity bot, ServerPlayerEntity p) {
        double dx = p.getX() - bot.getX(), dz = p.getZ() - bot.getZ();
        double len = Math.max(0.001, Math.sqrt(dx * dx + dz * dz));
        double x = p.getX() + dx / len * 2.5, z = p.getZ() + dz / len * 2.5;
        w.createExplosion(null, x, p.getY() + 0.2, z, 3.0f, World.ExplosionSourceType.NONE);
    }

    static void forceArena(ServerWorld w, boolean on) {
        for (int cx = (AX >> 4) - 2; cx <= (AX >> 4) + 2; cx++)
            for (int cz = (AZ >> 4) - 2; cz <= (AZ >> 4) + 2; cz++) {
                if (on) w.getChunk(cx, cz);
                w.setChunkForced(cx, cz, on);
            }
    }

    /** Mod tu chon bot theo giap dang mac: da/khong->noob, sat->normal, kim cuong->pro, netherite->cpvp */
    static Spec autoSpec(ServerPlayerEntity p) {
        int best = 0;
        for (int i = 0; i < 4; i++) {
            ItemStack st = p.getEquippedStack(SLOTS[i]);
            for (int t = 1; t <= 4; t++) if (st.isOf(ARMOR[t][i])) best = Math.max(best, t);
        }
        String key = best >= 4 ? "cpvp" : best == 3 ? "pro" : best == 2 ? "normal" : "noob";
        return SPECS.get(key);
    }

    // ===== Dau truong =====
    static void buildArena(ServerWorld w) {
        for (int dx = -12; dx <= 12; dx++) {
            for (int dz = -12; dz <= 12; dz++) {
                boolean edge = Math.abs(dx) == 12 || Math.abs(dz) == 12;
                DonutLike.set(w, new BlockPos(AX + dx, AY - 1, AZ + dz), (dx + dz) % 4 == 0 ? Blocks.SEA_LANTERN : Blocks.DEEPSLATE_TILES);
                for (int dy = 0; dy <= 6; dy++) {
                    Block b = (edge && dy <= 5) ? Blocks.GLASS : Blocks.AIR;
                    DonutLike.set(w, new BlockPos(AX + dx, AY + dy, AZ + dz), b);
                }
            }
        }
    }

    static void attr(LivingEntity e, RegistryEntry<EntityAttribute> a, double v) {
        EntityAttributeInstance i = e.getAttributeInstance(a);
        if (i != null) i.setBaseValue(v);
    }
}
