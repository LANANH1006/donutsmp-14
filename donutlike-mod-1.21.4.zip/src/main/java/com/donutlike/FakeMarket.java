package com.donutlike;

import com.mojang.brigadier.CommandDispatcher;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.component.type.LoreComponent;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.inventory.SimpleInventory;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.screen.GenericContainerScreenHandler;
import net.minecraft.screen.ScreenHandlerType;
import net.minecraft.screen.SimpleNamedScreenHandlerFactory;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.command.ServerCommandSource;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;

import java.util.*;

import static net.minecraft.server.command.CommandManager.literal;

/**
 * Cho "ao" de choi mot minh:
 *  - /sell : GUI order cua NGUOI MUA AO (ten ao). Click = ban 1 stack, shift+click = ban het (toi da so con can).
 *  - Order cua BAN (/orders create ...) se duoc NGUOI BAN AO giao dan dan neu gia du hop ly.
 */
public class FakeMarket {

    static final String[] FAKE_NAMES = {"Alex_VN", "DonutKing", "xX_Miner_Xx", "Hana", "Bao123", "NoobMaster", "Zephyr", "TanSMP",
        "Minh_PvP", "CrystalGod", "Linh", "ShadowFox", "Kiet_TV", "PandaGamer", "Nguyen_MC", "Thanh2k8", "ObsidianLord", "EnderQueen",
        "Duc_Cpvp", "MeoMeo", "BigTotem", "RaidKing", "FarmBot99", "SkyBlockVN", "Quan_Mine", "TrangPro", "LavaCake", "IronGolem_", "Phuc_SMP", "DragonSlay"};

    static final Item[] POOL = {
        Items.DIAMOND, Items.EMERALD, Items.IRON_INGOT, Items.GOLD_INGOT, Items.NETHERITE_INGOT, Items.COAL, Items.REDSTONE,
        Items.LAPIS_LAZULI, Items.COPPER_INGOT, Items.OBSIDIAN, Items.ENDER_PEARL, Items.BLAZE_ROD, Items.GOLDEN_APPLE, Items.QUARTZ,
        Items.OAK_LOG, Items.COBBLESTONE, Items.DIRT, Items.SAND, Items.BONE, Items.GUNPOWDER, Items.STRING, Items.SLIME_BALL,
        Items.ROTTEN_FLESH, Items.SPIDER_EYE, Items.ARROW, Items.WHEAT, Items.CARROT, Items.POTATO, Items.SUGAR_CANE, Items.PUMPKIN,
        Items.MELON_SLICE, Items.COCOA_BEANS, Items.NETHER_WART, Items.GLOWSTONE_DUST, Items.END_STONE, Items.SHULKER_SHELL,
        Items.ANCIENT_DEBRIS, Items.DIAMOND_BLOCK, Items.IRON_BLOCK, Items.COOKED_BEEF, Items.BREAD, Items.TOTEM_OF_UNDYING
    };

    /** Bot chi giao order neu gia >= MIN_RATIO * gia tri item */
    static final double MIN_RATIO = 0.7;

    static class FO {
        String name; Item item; int remaining; double per; boolean ench;
    }

    static final List<FO> LIST = new ArrayList<>();
    static long bucket = -1;
    static final Random RND = new Random();

    /** Tat ca item co gia (>0) - moi item co 1 order co dinh gia. Tinh 1 lan. */
    static List<Item> ALL = null;
    static List<Item> all() {
        if (ALL == null) {
            List<Item> l = new ArrayList<>();
            for (Item it : net.minecraft.registry.Registries.ITEM) if (Prices.unit(it) > 0) l.add(it);
            ALL = l;
        }
        return ALL;
    }

    static String fakeName(Random r) { return FAKE_NAMES[r.nextInt(FAKE_NAMES.length)]; }

    /** 1 order cua bot cho item nay. Gia co dinh theo item (do full phu phep: Prices.enchUnit). bump = cong them % de cac order canh tranh nhau. */
    static FO makeFor(Random r, Item it, double bump) {
        FO o = new FO();
        o.name = fakeName(r);
        o.item = it;
        o.ench = Enchants.premiumGear(it);
        double base = o.ench ? Prices.enchUnit(it) : Math.max(0.5, Prices.unit(it));
        o.per = Math.round(base * (1.0 + bump) * 100.0) / 100.0;
        int stack = Math.max(1, Math.min(64, it.getMaxCount()));
        o.remaining = o.ench ? 1 + r.nextInt(6) : stack * (1 + r.nextInt(24));
        return o;
    }

    static FO make(Random r) {
        List<Item> a = all();
        return makeFor(r, a.get(r.nextInt(a.size())), 0);
    }

    static void ensure() {
        long b = System.currentTimeMillis() / 900_000L; // doi bo order moi 15 phut
        if (b == bucket && !LIST.isEmpty()) return;
        bucket = b;
        LIST.clear();
        Random r = new Random(b * 31 + 7);
        for (Item it : all()) {
            LIST.add(makeFor(r, it, 0));
            // vat pham dat tien (elytra, dau rong, netherite...): nhieu nguoi order 1 mon, canh tranh gia
            if (Prices.unit(it) >= 1000) {
                int k = 3 + r.nextInt(6);
                for (int i = 1; i <= k; i++) LIST.add(makeFor(r, it, i * (0.01 + r.nextDouble() * 0.03)));
            }
        }
        // gia cao nhat (elytra full phu phep, dau rong, trung rong...) len dau
        LIST.sort((x, y) -> Double.compare(y.per, x.per));
    }

    // ===== /ah: hang cua BOT (gia cao hon gia order) + hang troll =====
    static final List<Market.Listing> AH = new ArrayList<>();
    static long ahBucket = -1;

    static Market.Listing botListing(Random r, ItemStack st, double price) {
        String n = fakeName(r);
        Market.Listing l = new Market.Listing(UUID.nameUUIDFromBytes(("bot:" + n).getBytes()), n, st, price);
        l.bot = true;
        l.created = System.currentTimeMillis() - r.nextInt(3_600_000);
        return l;
    }

    static void ensureAh() {
        long b = System.currentTimeMillis() / 3_600_000L; // doi hang moi gio
        if (b == ahBucket && !AH.isEmpty()) return;
        ahBucket = b;
        AH.clear();
        Random r = new Random(b * 17 + 3);
        List<Item> a = all();
        for (int i = 0; i < 450; i++) {
            Item it = a.get(r.nextInt(a.size()));
            ItemStack st;
            double unit;
            if (Enchants.premiumGear(it)) { st = Enchants.full(it); unit = Prices.enchUnit(it); }
            else { st = new ItemStack(it, 1 + r.nextInt(Math.max(1, Math.min(64, it.getMaxCount())))); unit = Prices.unit(it) * st.getCount(); }
            // /ah luon DAT HON gia order (order tra ~1.0x gia goc)
            double price = Math.round(unit * (1.25 + r.nextDouble() * 0.9) * 100.0) / 100.0;
            AH.add(botListing(r, st, price));
        }
        // elytra / do full phu phep dang canh tranh nhau o /ah
        for (Item it : new Item[]{Items.ELYTRA, Items.NETHERITE_CHESTPLATE, Items.NETHERITE_SWORD, Items.MACE, Items.TRIDENT}) {
            for (int i = 0; i < 4; i++)
                AH.add(botListing(r, Enchants.full(it), Math.round(Prices.enchUnit(it) * (1.3 + r.nextDouble() * 0.8) * 100.0) / 100.0));
        }
        // hang TROLL
        Object[][] troll = {
            {Items.DIRT, 1, 500e9}, {Items.STICK, 1, 1e12}, {Items.COBBLESTONE, 64, 250e9}, {Items.WOODEN_SWORD, 1, 999e9},
            {Items.POISONOUS_POTATO, 1, 300e9}, {Items.DEAD_BUSH, 1, 100e9}, {Items.ROTTEN_FLESH, 16, 750e9}, {Items.SAND, 1, 420e9},
            {Items.OAK_SAPLING, 1, 2e12}, {Items.BOWL, 1, 69e9}
        };
        for (Object[] t : troll) AH.add(botListing(r, new ItemStack((Item) t[0], (Integer) t[1]), (Double) t[2]));
    }

    static void init() { }

    static void register(CommandDispatcher<ServerCommandSource> d) {
        d.register(literal("sell").requires(s -> Admin.on("orders")).executes(c -> { open(c.getSource().getPlayerOrThrow()); return 1; }));
    }

    static void open(ServerPlayerEntity p) {
        ensure();
        Market.openOrders(p, 0, null);
    }

    // ===== Nguoi ban ao giao hang cho order cua ban =====
    static void tick(MinecraftServer s) {
        if (DonutLike.tick % 100 != 0 || !Admin.on("bots")) return;
        if (Admin.on("ah")) botBuyAh();
        if (!Admin.on("orders")) return;
        Iterator<Market.Order> it = Market.ORDERS.iterator();
        while (it.hasNext()) {
            Market.Order o = it.next();
            if (System.currentTimeMillis() - o.created < 8000) continue;
            ServerPlayerEntity buyer = s.getPlayerManager().getPlayer(o.buyer);
            if (buyer == null) continue;
            double unit = Prices.unit(o.template.getItem());
            if (o.perItem < unit * MIN_RATIO) continue;          // gia qua thap -> bot khong giao
            int n = Math.max(1, (int) (o.remaining * (0.15 + RND.nextDouble() * 0.35)));
            n = Math.min(n, o.remaining);
            int left = n;
            while (left > 0) {
                int c = Math.min(o.template.getMaxCount(), left);
                buyer.getInventory().offerOrDrop(o.template.copyWithCount(c));
                left -= c;
            }
            o.remaining -= n;
            String who = FAKE_NAMES[RND.nextInt(FAKE_NAMES.length)];
            DonutLike.msg(buyer, "§a[Order] " + who + " đã giao " + n + "x " + o.template.getName().getString()
                + (o.remaining > 0 ? " (còn " + o.remaining + ")" : " — order hoàn tất"));
            if (o.remaining <= 0) it.remove();
        }
    }

    // ===== Bot mua do dang tren /ah =====
    static void botBuyAh() {
        long now = System.currentTimeMillis();
        int bought = 0;
        for (Market.Listing l : new ArrayList<>(Market.LISTINGS)) {
            if (bought >= 2) break;
            if (now - l.created < 15_000) continue;                 // moi dang: doi 15s
            double fair = Prices.stack(l.stack);
            if (fair <= 0) continue;                                // khong dinh gia duoc -> bot khong mua
            double ratio = l.price / fair;
            if (ratio > 1.6) continue;                              // qua dat
            double chance = ratio <= 1.0 ? 0.6 : ratio <= 1.25 ? 0.3 : 0.1;
            if (RND.nextDouble() > chance) continue;
            if (!Market.LISTINGS.remove(l)) continue;
            DonutLike.add(l.seller, l.price);
            bought++;
            String who = FAKE_NAMES[RND.nextInt(FAKE_NAMES.length)];
            ServerPlayerEntity seller = DonutLike.SERVER == null ? null : DonutLike.SERVER.getPlayerManager().getPlayer(l.seller);
            if (seller != null) {
                ShopHandler.ting(seller);
                DonutLike.msg(seller, "§a[AH] " + who + " đã mua " + l.stack.getName().getString() + " với giá $" + Prices.money(l.price));
            }
        }
    }

    /** Ban cho 1 order cua bot (dung chung cho /sell va /orders) */
    static void sell(ServerPlayerEntity sp, FO o, boolean all) {
        if (!LIST.contains(o)) { DonutLike.msg(sp, "§cOrder này không còn."); return; }
        int limit = all ? o.remaining : Math.min(o.remaining, Math.max(1, o.item.getMaxCount()));
        int given = 0;
        PlayerInventory pi = sp.getInventory();
        for (int i = 0; i < 36 && given < limit; i++) {
            ItemStack s = pi.getStack(i);
            if (s.isEmpty() || !s.isOf(o.item) || s.get(DataComponentTypes.CUSTOM_DATA) != null) continue;
            if (o.ench != s.hasEnchantments()) continue; // order full phu phep chi nhan do co phu phep (va nguoc lai)
            int n = Math.min(s.getCount(), limit - given);
            s.decrement(n);
            given += n;
        }
        if (given == 0) { DonutLike.msg(sp, o.ench ? "§cOrder này cần đồ FULL phù phép trong túi bạn." : "§cBạn không có vật phẩm phù hợp trong túi."); return; }
        double pay = o.per * given;
        DonutLike.add(sp.getUuid(), pay);
        o.remaining -= given;
        ShopHandler.ting(sp);
        DonutLike.msg(sp, "§a[Sell] Đã bán " + given + "x " + new ItemStack(o.item).getName().getString()
            + " cho " + o.name + ": §e+$" + Prices.money(pay));
        if (o.remaining <= 0) {
            int idx = LIST.indexOf(o);
            if (idx >= 0) LIST.set(idx, make(RND));
        }
    }
}
